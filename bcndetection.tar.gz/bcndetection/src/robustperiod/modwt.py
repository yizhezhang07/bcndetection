# Adopted from https://github.com/pistonly/modwtpy/blob/master/modwt.py

import pywt
import numpy as np


def circular_convolve_d(h_t, v_j_1, j):
    '''
    jth level decomposition
    h_t: \tilde{h} = h / sqrt(2)
    v_j_1: v_{j-1}, the (j-1)th scale coefficients
    return: w_j (or v_j)
    '''
    N = len(v_j_1)
    
    L = len(h_t)

    # Matching the paper
    L_j = min(N, (2**4-1)*(L-1))

    w_j = np.zeros(N)
    l = np.arange(L)

    for t in range(N):
        index = np.mod(t - 2 ** (j - 1) * l, N)
        v_p = np.array([v_j_1[ind] for ind in index])
        # Keeping up to L_j items
        w_j[t] = (np.array(h_t)[:L_j] * v_p[:L_j]).sum()
    return w_j


def modwt(x, filters, level):
    '''
    filters: 'db1', 'db2', 'haar', ...
    return: see matlab
    '''
    # filter
    wavelet = pywt.Wavelet(filters)
    h = wavelet.dec_hi
    g = wavelet.dec_lo
    h_t = np.array(h) / np.sqrt(2)
    g_t = np.array(g) / np.sqrt(2)
    wavecoeff = []
    v_j_1 = x
    for j in range(level):
        w = circular_convolve_d(h_t, v_j_1, j + 1)
        v_j_1 = circular_convolve_d(g_t, v_j_1, j + 1)
        # if j > 0:
        wavecoeff.append(w)
    # wavecoeff.append(v_j_1)
    return np.vstack(wavecoeff)